/*
Você será responsável por criar um programa, utilizando seus conhecimento em JavaScript, 
que calcula o IMC de um indivíduo e alerta o usuário se ele tem maior risco ao contrair 
o COVID-19 (true) caso o valor do IMC for maior ou igual do que 30 ou menor risco, 
IMC menor do que 30 (false).
• Será necessário o usuário entrar com os dados de altura (m) e peso (kg).
• Calcular o IMC
• Alertar o usuário o resultado (true ou false)
*/

function calcula_imc() {
    let altura = document.imcForm.altura.value;
    let peso = document.imcForm.peso.value;
    let quadrado = (altura ** 2);
    let calculo = (peso/quadrado);
    let resultado = Math.round(calculo);
    
 
    if(calculo < 30) {
    alert(" Falso - Sobrepeso, está fora do risco de contrair Covid19 e o seu IMC é: " + resultado);
    }
    else if(calculo >= 30 && calculo < 39.9) {
    alert("Verdadeiro - Obesidade, tem risco de contrair Codiv19 e o seu IMC é: " + resultado);
    }
    else if (calculo > 40)
    alert("Verdadeiro - Obesidade Grave, tem risco alto de contrair Codiv19 e o seu IMC é: " + resultado);
    }